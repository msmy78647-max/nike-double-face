<?php
/**
 * صفحات الأرشيف والفئات
 * 
 * @package Med-Shop
 */

get_header();
?>

<div class="container">
    <div style="margin: 40px 0;">
        <!-- رأس الأرشيف -->
        <div class="category-header">
            <?php
            if ( is_category() ) {
                echo '<h1>' . single_cat_title( '', false ) . '</h1>';
                echo '<p>' . category_description() . '</p>';
            } elseif ( is_tag() ) {
                echo '<h1>' . single_tag_title( '', false ) . '</h1>';
                echo '<p>' . tag_description() . '</p>';
            } elseif ( is_author() ) {
                echo '<h1>' . get_the_author() . '</h1>';
            } elseif ( is_date() ) {
                if ( is_day() ) {
                    echo '<h1>' . get_the_date() . '</h1>';
                } elseif ( is_month() ) {
                    echo '<h1>' . get_the_date( 'F Y' ) . '</h1>';
                } elseif ( is_year() ) {
                    echo '<h1>' . get_the_date( 'Y' ) . '</h1>';
                }
            } else {
                echo '<h1>' . __( 'الأرشيف', 'med-shop' ) . '</h1>';
            }
            ?>
        </div>

        <!-- المحتوى -->
        <div class="archive-content">
            <?php
            if ( have_posts() ) {
                while ( have_posts() ) {
                    the_post();
                    ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="margin-bottom: 30px; padding-bottom: 30px; border-bottom: 1px solid #e0e0e0;">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="entry-meta" style="color: #666; margin-bottom: 15px;">
                            <?php
                            echo '<span>' . get_the_date() . '</span>';
                            echo ' | ';
                            echo '<span>' . get_the_author() . '</span>';
                            ?>
                        </div>
                        <div class="entry-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="btn" style="margin-top: 15px;">
                            <?php _e( 'اقرأ المزيد', 'med-shop' ); ?>
                        </a>
                    </article>
                    <?php
                }

                // الترقيم
                echo '<div style="margin-top: 40px; text-align: center;">';
                the_posts_pagination( array(
                    'mid_size' => 2,
                    'prev_text' => __( 'السابق', 'med-shop' ),
                    'next_text' => __( 'التالي', 'med-shop' ),
                ) );
                echo '</div>';
            } else {
                echo '<p>' . __( 'لم يتم العثور على محتوى', 'med-shop' ) . '</p>';
            }
            ?>
        </div>
    </div>
</div>

<?php
get_footer();
