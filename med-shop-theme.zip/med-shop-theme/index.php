<?php
/**
 * الصفحة الرئيسية للقالب
 * 
 * @package Med-Shop
 */

get_header();
?>

<div class="container">
    <div class="page-content">
        <?php
        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <?php
                        if ( is_singular() ) {
                            the_title( '<h1 class="entry-title">', '</h1>' );
                        } else {
                            the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
                        }
                        ?>
                    </header>

                    <div class="entry-content">
                        <?php
                        the_excerpt();
                        ?>
                    </div>
                </article>
                <?php
            }
        } else {
            ?>
            <p><?php _e( 'لم يتم العثور على محتوى', 'med-shop' ); ?></p>
            <?php
        }
        ?>
    </div>
</div>

<?php
get_footer();
