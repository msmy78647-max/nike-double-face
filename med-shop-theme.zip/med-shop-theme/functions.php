<?php
/**
 * Med-Shop Theme Functions
 * 
 * @package Med-Shop
 * @version 1.0.0
 */

// منع الوصول المباشر
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// تعريف ثوابت القالب
define( 'MED_SHOP_VERSION', '1.0.0' );
define( 'MED_SHOP_DIR', get_template_directory() );
define( 'MED_SHOP_URI', get_template_directory_uri() );

/**
 * إعداد القالب
 */
function med_shop_setup() {
    // دعم اللغات
    load_theme_textdomain( 'med-shop', MED_SHOP_DIR . '/languages' );

    // دعم الشعار المخصص
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // دعم الخلفيات المخصصة
    add_theme_support( 'custom-background' );

    // دعم الألوان المخصصة
    add_theme_support( 'custom-colors' );

    // دعم WooCommerce
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    // دعم HTML5
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'script',
        'style',
    ) );

    // دعم Post Thumbnails
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 250, 250, true );

    // تسجيل القوائم
    register_nav_menus( array(
        'primary-menu'   => __( 'القائمة الرئيسية', 'med-shop' ),
        'footer-menu'    => __( 'قائمة الفوتر', 'med-shop' ),
        'mobile-menu'    => __( 'قائمة الجوال', 'med-shop' ),
    ) );
}
add_action( 'after_setup_theme', 'med_shop_setup' );

/**
 * تحميل الأنماط والسكريبتات
 */
function med_shop_enqueue_assets() {
    // CSS الرئيسي
    wp_enqueue_style( 'med-shop-style', MED_SHOP_URI . '/style.css', array(), MED_SHOP_VERSION );

    // Font Awesome
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0' );

    // Google Fonts
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;600;700&display=swap', array(), null );

    // JavaScript الرئيسي
    wp_enqueue_script( 'med-shop-main', MED_SHOP_URI . '/assets/js/main.js', array( 'jquery' ), MED_SHOP_VERSION, true );

    // WooCommerce Scripts
    wp_enqueue_script( 'med-shop-woocommerce', MED_SHOP_URI . '/assets/js/woocommerce.js', array( 'jquery' ), MED_SHOP_VERSION, true );

    // Localize script
    wp_localize_script( 'med-shop-main', 'medShopData', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'med-shop-nonce' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'med_shop_enqueue_assets' );

/**
 * تسجيل مناطق الويدجت
 */
function med_shop_register_sidebars() {
    register_sidebar( array(
        'name'          => __( 'الشريط الجانبي الرئيسي', 'med-shop' ),
        'id'            => 'primary-sidebar',
        'description'   => __( 'الشريط الجانبي الرئيسي', 'med-shop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'الفوتر - العمود الأول', 'med-shop' ),
        'id'            => 'footer-col-1',
        'description'   => __( 'الفوتر - العمود الأول', 'med-shop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'الفوتر - العمود الثاني', 'med-shop' ),
        'id'            => 'footer-col-2',
        'description'   => __( 'الفوتر - العمود الثاني', 'med-shop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'الفوتر - العمود الثالث', 'med-shop' ),
        'id'            => 'footer-col-3',
        'description'   => __( 'الفوتر - العمود الثالث', 'med-shop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'الفوتر - العمود الرابع', 'med-shop' ),
        'id'            => 'footer-col-4',
        'description'   => __( 'الفوتر - العمود الرابع', 'med-shop' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'med_shop_register_sidebars' );

/**
 * إضافة فئات مخصصة للقائمة
 */
function med_shop_nav_menu_link_attributes( $atts, $item, $args ) {
    if ( $args->theme_location === 'primary-menu' ) {
        $atts['class'] = isset( $atts['class'] ) ? $atts['class'] . ' menu-link' : 'menu-link';
    }
    return $atts;
}
add_filter( 'nav_menu_link_attributes', 'med_shop_nav_menu_link_attributes', 10, 3 );

/**
 * تخصيص WooCommerce
 */
function med_shop_woocommerce_customization() {
    // تعديل عدد المنتجات في الصفحة
    add_filter( 'loop_shop_per_page', function() {
        return 12;
    } );

    // تعديل عدد الأعمدة
    add_filter( 'loop_shop_columns', function() {
        return 4;
    } );
}
add_action( 'wp', 'med_shop_woocommerce_customization' );

/**
 * إضافة رسالة الدفع عند الاستلام
 */
function med_shop_cod_message() {
    if ( is_checkout() ) {
        echo '<div class="woocommerce-info">';
        echo __( 'التوصيل مجاني في جميع مدن المغرب. الدفع عند الاستلام.', 'med-shop' );
        echo '</div>';
    }
}
add_action( 'woocommerce_before_checkout_form', 'med_shop_cod_message' );

/**
 * تعديل رسالة الشحن
 */
function med_shop_shipping_message() {
    echo '<div class="shipping-info">';
    echo __( 'التوصيل مجاني في جميع أنحاء المغرب', 'med-shop' );
    echo '</div>';
}

/**
 * إضافة خيار الدفع عند الاستلام فقط
 */
function med_shop_available_payment_gateways( $gateways ) {
    // التأكد من أن الدفع عند الاستلام هو الخيار الوحيد
    $cod_gateway = isset( $gateways['cod'] ) ? $gateways['cod'] : null;
    
    if ( $cod_gateway ) {
        $gateways = array( 'cod' => $cod_gateway );
    }
    
    return $gateways;
}
add_filter( 'woocommerce_available_payment_gateways', 'med_shop_available_payment_gateways' );

/**
 * إضافة حقل مخصص لرقم الهاتف في الشيكاوت
 */
function med_shop_custom_checkout_fields( $fields ) {
    $fields['billing']['billing_phone']['required'] = true;
    $fields['billing']['billing_phone']['label'] = __( 'رقم الهاتف', 'med-shop' );
    
    return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'med_shop_custom_checkout_fields' );

/**
 * إضافة فئات المنتجات تلقائياً
 */
function med_shop_create_product_categories() {
    $categories = array(
        array(
            'name' => __( 'أحذية رجالية', 'med-shop' ),
            'slug' => 'mens-shoes',
            'description' => __( 'مجموعة متنوعة من الأحذية الرجالية الشتوية', 'med-shop' ),
        ),
        array(
            'name' => __( 'جاكيتات', 'med-shop' ),
            'slug' => 'jackets',
            'description' => __( 'جاكيتات شتوية فاخرة للرجال', 'med-shop' ),
        ),
        array(
            'name' => __( 'أونسومبل', 'med-shop' ),
            'slug' => 'ensembles',
            'description' => __( 'مجموعات ملابس متكاملة', 'med-shop' ),
        ),
    );

    foreach ( $categories as $category ) {
        if ( ! term_exists( $category['slug'], 'product_cat' ) ) {
            wp_insert_term(
                $category['name'],
                'product_cat',
                array(
                    'slug'        => $category['slug'],
                    'description' => $category['description'],
                )
            );
        }
    }
}
register_activation_hook( __FILE__, 'med_shop_create_product_categories' );

/**
 * إضافة رسالة الشراء الحديث
 */
function med_shop_recent_purchase_notification() {
    if ( is_product() ) {
        echo '<script>
            document.addEventListener("DOMContentLoaded", function() {
                // محاكاة إشعار الشراء الحديث
                var products = ["حذاء رجالي أسود", "جاكيت شتوي", "أونسومبل فاخر"];
                var randomProduct = products[Math.floor(Math.random() * products.length)];
                
                setTimeout(function() {
                    showNotification(randomProduct);
                }, 3000);
            });
            
            function showNotification(product) {
                var notification = document.createElement("div");
                notification.className = "notification-popup";
                notification.innerHTML = `
                    <div class="notification-content">
                        <div class="notification-icon">✓</div>
                        <div class="notification-text">
                            <strong>تم شراء هذا المنتج</strong>
                            <p>تم شراء ${product} قبل لحظات</p>
                        </div>
                        <div class="notification-close" onclick="this.parentElement.parentElement.remove()">×</div>
                    </div>
                `;
                document.body.appendChild(notification);
                
                setTimeout(function() {
                    if (notification.parentElement) {
                        notification.remove();
                    }
                }, 5000);
            }
        </script>';
    }
}
add_action( 'wp_footer', 'med_shop_recent_purchase_notification' );

/**
 * إضافة زر الواتساب العائم
 */
function med_shop_whatsapp_button() {
    $whatsapp_number = get_option( 'med_shop_whatsapp_number', '212612345678' );
    $whatsapp_message = __( 'مرحباً، أود الاستفسار عن المنتجات', 'med-shop' );
    
    echo '<a href="https://wa.me/' . esc_attr( $whatsapp_number ) . '?text=' . urlencode( $whatsapp_message ) . '" class="whatsapp-btn" target="_blank" title="' . __( 'تواصل معنا عبر الواتساب', 'med-shop' ) . '">
        <i class="fab fa-whatsapp"></i>
    </a>';
}
add_action( 'wp_footer', 'med_shop_whatsapp_button' );

/**
 * إضافة خيارات القالب في لوحة التحكم
 */
function med_shop_customize_register( $wp_customize ) {
    // قسم معلومات المتجر
    $wp_customize->add_section( 'med_shop_store_info', array(
        'title' => __( 'معلومات المتجر', 'med-shop' ),
        'priority' => 10,
    ) );

    // رقم الهاتف
    $wp_customize->add_setting( 'med_shop_phone', array(
        'default' => '+212 6 12 34 56 78',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'med_shop_phone', array(
        'label' => __( 'رقم الهاتف', 'med-shop' ),
        'section' => 'med_shop_store_info',
        'type' => 'text',
    ) );

    // رقم الواتساب
    $wp_customize->add_setting( 'med_shop_whatsapp_number', array(
        'default' => '212612345678',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'med_shop_whatsapp_number', array(
        'label' => __( 'رقم الواتساب (بدون علامات)', 'med-shop' ),
        'section' => 'med_shop_store_info',
        'type' => 'text',
    ) );

    // حساب إنستغرام
    $wp_customize->add_setting( 'med_shop_instagram', array(
        'default' => '@med-shop',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'med_shop_instagram', array(
        'label' => __( 'حساب إنستغرام', 'med-shop' ),
        'section' => 'med_shop_store_info',
        'type' => 'text',
    ) );

    // البريد الإلكتروني
    $wp_customize->add_setting( 'med_shop_email', array(
        'default' => 'info@med-shop.ma',
        'sanitize_callback' => 'sanitize_email',
    ) );

    $wp_customize->add_control( 'med_shop_email', array(
        'label' => __( 'البريد الإلكتروني', 'med-shop' ),
        'section' => 'med_shop_store_info',
        'type' => 'email',
    ) );
}
add_action( 'customize_register', 'med_shop_customize_register' );

/**
 * دالة مساعدة للحصول على معلومات المتجر
 */
function med_shop_get_store_info( $key ) {
    $defaults = array(
        'phone' => '+212 6 12 34 56 78',
        'whatsapp_number' => '212612345678',
        'instagram' => '@med-shop',
        'email' => 'info@med-shop.ma',
    );

    $value = get_option( 'med_shop_' . $key, $defaults[ $key ] ?? '' );
    return $value;
}

/**
 * إضافة فئات مخصصة للجسم
 */
function med_shop_body_class( $classes ) {
    $classes[] = 'med-shop-theme';
    
    if ( is_product() ) {
        $classes[] = 'single-product-page';
    }
    
    if ( is_product_category() ) {
        $classes[] = 'product-category-page';
    }
    
    return $classes;
}
add_filter( 'body_class', 'med_shop_body_class' );

/**
 * تعطيل تعليقات المنتجات
 */
function med_shop_disable_product_comments() {
    if ( is_product() ) {
        add_filter( 'comments_open', '__return_false', 20 );
        add_filter( 'pings_open', '__return_false', 20 );
    }
}
add_action( 'wp', 'med_shop_disable_product_comments' );

/**
 * إضافة دعم الترجمة
 */
function med_shop_load_textdomain() {
    load_theme_textdomain( 'med-shop', MED_SHOP_DIR . '/languages' );
}
add_action( 'after_setup_theme', 'med_shop_load_textdomain' );
