<?php
/**
 * صفحة الخطأ 404
 * 
 * @package Med-Shop
 */

get_header();
?>

<div class="container">
    <div style="margin: 80px 0; text-align: center;">
        <div style="font-size: 120px; color: #FC6E20; margin-bottom: 20px;">
            404
        </div>
        <h1 style="font-size: 2.5rem; margin-bottom: 20px;">
            <?php _e( 'الصفحة غير موجودة', 'med-shop' ); ?>
        </h1>
        <p style="font-size: 1.2rem; color: #666; margin-bottom: 40px;">
            <?php _e( 'عذراً، الصفحة التي تبحث عنها غير موجودة أو قد تم حذفها.', 'med-shop' ); ?>
        </p>

        <div style="margin-bottom: 40px;">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn">
                <?php _e( 'العودة للرئيسية', 'med-shop' ); ?>
            </a>
            <a href="<?php echo esc_url( home_url( '/shop' ) ); ?>" class="btn btn-secondary" style="margin-right: 15px;">
                <?php _e( 'تصفح المتجر', 'med-shop' ); ?>
            </a>
        </div>

        <!-- اقتراحات البحث -->
        <div style="background-color: #F5F5F5; padding: 30px; border-radius: 8px; margin-top: 40px;">
            <h3><?php _e( 'هل تريد البحث؟', 'med-shop' ); ?></h3>
            <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="margin-top: 20px;">
                <div style="display: flex; gap: 10px; max-width: 500px; margin: 0 auto;">
                    <input type="search" name="s" placeholder="<?php _e( 'ابحث عن المنتجات...', 'med-shop' ); ?>" style="flex: 1; padding: 12px; border: 1px solid #e0e0e0; border-radius: 4px;">
                    <button type="submit" class="btn">
                        <?php _e( 'بحث', 'med-shop' ); ?>
                    </button>
                </div>
            </form>
        </div>

        <!-- الأقسام الشهيرة -->
        <div style="margin-top: 40px;">
            <h3><?php _e( 'الأقسام الشهيرة', 'med-shop' ); ?></h3>
            <div style="display: flex; gap: 20px; justify-content: center; margin-top: 20px; flex-wrap: wrap;">
                <a href="<?php echo esc_url( home_url( '/product-category/mens-shoes' ) ); ?>" class="btn btn-secondary">
                    <?php _e( 'أحذية رجالية', 'med-shop' ); ?>
                </a>
                <a href="<?php echo esc_url( home_url( '/product-category/jackets' ) ); ?>" class="btn btn-secondary">
                    <?php _e( 'جاكيتات', 'med-shop' ); ?>
                </a>
                <a href="<?php echo esc_url( home_url( '/product-category/ensembles' ) ); ?>" class="btn btn-secondary">
                    <?php _e( 'أونسومبل', 'med-shop' ); ?>
                </a>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
