<?php
/**
 * رأس الصفحة
 * 
 * @package Med-Shop
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php bloginfo( 'description' ); ?>">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <!-- الشريط العلوي -->
    <div class="header-top">
        <div class="container">
            <div class="header-top-content">
                <div class="header-contact">
                    <span>
                        <i class="fas fa-phone"></i>
                        <a href="tel:<?php echo esc_attr( med_shop_get_store_info( 'phone' ) ); ?>">
                            <?php echo esc_html( med_shop_get_store_info( 'phone' ) ); ?>
                        </a>
                    </span>
                    <span>
                        <i class="fas fa-envelope"></i>
                        <a href="mailto:<?php echo esc_attr( med_shop_get_store_info( 'email' ) ); ?>">
                            <?php echo esc_html( med_shop_get_store_info( 'email' ) ); ?>
                        </a>
                    </span>
                </div>
                <div class="social-links">
                    <a href="https://wa.me/<?php echo esc_attr( med_shop_get_store_info( 'whatsapp_number' ) ); ?>" title="واتساب" target="_blank">
                        <i class="fab fa-whatsapp"></i>
                    </a>
                    <a href="https://instagram.com/<?php echo esc_attr( str_replace( '@', '', med_shop_get_store_info( 'instagram' ) ) ); ?>" title="إنستغرام" target="_blank">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- الهيدر الرئيسي -->
    <header class="site-header">
        <div class="container">
            <div class="header-main">
                <!-- الشعار -->
                <div class="site-logo">
                    <?php
                    if ( has_custom_logo() ) {
                        the_custom_logo();
                    } else {
                        ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo-text">
                            <?php bloginfo( 'name' ); ?>
                        </a>
                        <?php
                    }
                    ?>
                </div>

                <!-- القائمة الرئيسية -->
                <nav class="header-nav">
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'primary-menu',
                        'menu_class'     => 'main-menu',
                        'container'      => false,
                        'fallback_cb'    => 'wp_page_menu',
                        'depth'          => 2,
                    ) );
                    ?>
                </nav>

                <!-- أيقونات الإجراءات -->
                <div class="header-actions">
                    <span class="search-icon" id="search-toggle">
                        <i class="fas fa-search"></i>
                    </span>
                    <span class="cart-icon" style="position: relative;">
                        <i class="fas fa-shopping-cart"></i>
                        <?php
                        if ( function_exists( 'WC' ) ) {
                            $cart_count = WC()->cart->get_cart_contents_count();
                            if ( $cart_count > 0 ) {
                                echo '<span class="cart-count">' . esc_html( $cart_count ) . '</span>';
                            }
                        }
                        ?>
                    </span>
                </div>
            </div>
        </div>
    </header>

    <!-- شريط البحث المخفي -->
    <div id="search-bar" style="display: none; background-color: #f5f5f5; padding: 20px 0; border-bottom: 1px solid #e0e0e0;">
        <div class="container">
            <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search-form">
                <input type="search" name="s" placeholder="<?php _e( 'ابحث عن المنتجات...', 'med-shop' ); ?>" value="<?php echo get_search_query(); ?>">
                <button type="submit" class="btn"><?php _e( 'بحث', 'med-shop' ); ?></button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var searchToggle = document.getElementById('search-toggle');
            var searchBar = document.getElementById('search-bar');

            if (searchToggle && searchBar) {
                searchToggle.addEventListener('click', function() {
                    if (searchBar.style.display === 'none') {
                        searchBar.style.display = 'block';
                    } else {
                        searchBar.style.display = 'none';
                    }
                });
            }
        });
    </script>
