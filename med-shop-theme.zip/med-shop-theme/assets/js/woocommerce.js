/**
 * Med-Shop Theme - WooCommerce Customizations
 * 
 * @package Med-Shop
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // تهيئة خيارات المنتج
        initProductOptions();
        
        // تهيئة زر الإضافة للسلة
        initAddToCart();
        
        // تهيئة الكمية
        initQuantity();
    });

    /**
     * تهيئة خيارات المنتج (الحجم واللون)
     */
    function initProductOptions() {
        // معالجة اختيار الحجم
        $('.size-option').on('click', function() {
            $('.size-option').removeClass('selected');
            $(this).addClass('selected');
        });

        // معالجة اختيار اللون
        $('.color-option').on('click', function() {
            $('.color-option').removeClass('selected');
            $(this).addClass('selected');
        });
    }

    /**
     * تهيئة زر الإضافة للسلة
     */
    function initAddToCart() {
        $('button.single_add_to_cart_button').on('click', function() {
            const productId = $(this).data('product_id');
            const quantity = $('input.qty').val() || 1;

            // إضافة تأثير بصري
            $(this).prop('disabled', true).text('جاري الإضافة...');

            setTimeout(function() {
                $(this).prop('disabled', false).text('أضف للسلة');
            }.bind(this), 1000);
        });
    }

    /**
     * تهيئة التحكم بالكمية
     */
    function initQuantity() {
        // زر الزيادة
        $('.quantity-control button:first-child').on('click', function() {
            const input = $(this).siblings('input');
            let value = parseInt(input.val()) || 1;
            input.val(value - 1);
        });

        // زر الإنقاص
        $('.quantity-control button:last-child').on('click', function() {
            const input = $(this).siblings('input');
            let value = parseInt(input.val()) || 1;
            input.val(value + 1);
        });

        // التحقق من الكمية
        $('.quantity-control input').on('change', function() {
            let value = parseInt($(this).val()) || 1;
            if (value < 1) {
                $(this).val(1);
            }
        });
    }

    /**
     * معالجة الفلاتر المتقدمة
     */
    window.applyAdvancedFilters = function() {
        const sizes = [];
        const colors = [];
        const minPrice = $('input[name="min_price"]').val() || 0;
        const maxPrice = $('input[name="max_price"]').val() || 10000;

        $('input[name="size"]:checked').each(function() {
            sizes.push($(this).val());
        });

        $('input[name="color"]:checked').each(function() {
            colors.push($(this).val());
        });

        // بناء رابط الفلترة
        let filterUrl = window.location.href.split('?')[0] + '?';

        if (sizes.length > 0) {
            filterUrl += 'size=' + sizes.join(',') + '&';
        }

        if (colors.length > 0) {
            filterUrl += 'color=' + colors.join(',') + '&';
        }

        filterUrl += 'min_price=' + minPrice + '&max_price=' + maxPrice;

        window.location.href = filterUrl;
    };

    /**
     * معالجة مراجعات المنتجات
     */
    window.submitProductReview = function() {
        const rating = $('input[name="rating"]:checked').val() || 0;
        const review = $('textarea[name="comment"]').val();
        const productId = $('input[name="product_id"]').val();

        if (!review) {
            alert('يرجى كتابة تقييم');
            return;
        }

        $.ajax({
            url: medShopData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'med_shop_submit_review',
                nonce: medShopData.nonce,
                product_id: productId,
                rating: rating,
                review: review,
            },
            success: function(response) {
                if (response.success) {
                    alert('شكراً لتقييمك');
                    location.reload();
                } else {
                    alert('حدث خطأ، يرجى المحاولة لاحقاً');
                }
            },
        });
    };

    /**
     * معالجة الشيكاوت
     */
    $(document).on('change', 'input[name="billing_country"]', function() {
        // تحديث الشحن بناءً على الدولة
        $('body').trigger('update_checkout');
    });

    /**
     * إظهار رسالة التوصيل المجاني
     */
    $(document).on('woocommerce_checkout_updated', function() {
        const shippingCost = $('tr.shipping').find('.woocommerce-Price-amount').text();
        if (shippingCost === '0' || shippingCost === '') {
            $('tr.shipping').after('<tr class="free-shipping-message"><td colspan="2"><strong>التوصيل مجاني</strong></td></tr>');
        }
    });

})(jQuery);
