/**
 * Med-Shop Theme - JavaScript الرئيسي
 * 
 * @package Med-Shop
 */

(function($) {
    'use strict';

    // عند تحميل الصفحة
    $(document).ready(function() {
        // تهيئة الوظائف
        initSlider();
        initFilters();
        initNotifications();
        initCart();
    });

    /**
     * تهيئة السلايدر
     */
    function initSlider() {
        let currentSlide = 0;
        const slides = $('.hero-slide');
        const dots = $('.slider-dot');

        if (slides.length === 0) return;

        function showSlide(index) {
            slides.removeClass('active');
            dots.removeClass('active');

            slides.eq(index).addClass('active');
            dots.eq(index).addClass('active');
        }

        // تغيير السلايد تلقائياً
        setInterval(function() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }, 5000);

        // التحكم اليدوي
        dots.on('click', function() {
            currentSlide = $(this).index();
            showSlide(currentSlide);
        });
    }

    /**
     * تهيئة الفلاتر
     */
    function initFilters() {
        $('.filter-option input').on('change', function() {
            applyFilters();
        });

        $('.price-range input').on('change', function() {
            applyFilters();
        });
    }

    /**
     * تطبيق الفلاتر
     */
    function applyFilters() {
        const selectedSizes = [];
        const selectedColors = [];
        let minPrice = 0;
        let maxPrice = 10000;

        // جمع الفلاتر المختارة
        $('input[name="size"]:checked').each(function() {
            selectedSizes.push($(this).val());
        });

        $('input[name="color"]:checked').each(function() {
            selectedColors.push($(this).val());
        });

        const minPriceInput = $('input[name="min_price"]').val();
        const maxPriceInput = $('input[name="max_price"]').val();

        if (minPriceInput) minPrice = parseInt(minPriceInput);
        if (maxPriceInput) maxPrice = parseInt(maxPriceInput);

        // إرسال الفلاتر عبر AJAX
        $.ajax({
            url: medShopData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'med_shop_filter_products',
                nonce: medShopData.nonce,
                sizes: selectedSizes,
                colors: selectedColors,
                min_price: minPrice,
                max_price: maxPrice,
            },
            success: function(response) {
                if (response.success) {
                    $('.products-grid').html(response.data.html);
                }
            },
        });
    }

    /**
     * تهيئة الإشعارات
     */
    function initNotifications() {
        // إظهار إشعار الشراء الحديث بشكل عشوائي
        if ($('.product-card').length > 0) {
            setInterval(function() {
                const products = [
                    'حذاء رجالي أسود',
                    'جاكيت شتوي فاخر',
                    'أونسومبل متكامل',
                    'حذاء جلدي بني',
                    'جاكيت صوف دافئ',
                ];

                const randomProduct = products[Math.floor(Math.random() * products.length)];
                showNotification(randomProduct);
            }, 8000);
        }
    }

    /**
     * عرض الإشعارات
     */
    function showNotification(product) {
        const notification = $(`
            <div class="notification-popup">
                <div class="notification-content">
                    <div class="notification-icon">✓</div>
                    <div class="notification-text">
                        <strong>تم شراء هذا المنتج</strong>
                        <p>${product} تم شراؤه قبل لحظات</p>
                    </div>
                    <div class="notification-close">×</div>
                </div>
            </div>
        `);

        $('body').append(notification);

        notification.find('.notification-close').on('click', function() {
            notification.remove();
        });

        setTimeout(function() {
            notification.fadeOut(function() {
                $(this).remove();
            });
        }, 5000);
    }

    /**
     * تهيئة سلة التسوق
     */
    function initCart() {
        // تحديث عدد المنتجات في السلة
        $(document).on('added_to_cart', function() {
            updateCartCount();
        });

        $(document).on('removed_from_cart', function() {
            updateCartCount();
        });
    }

    /**
     * تحديث عدد المنتجات في السلة
     */
    function updateCartCount() {
        $.ajax({
            url: medShopData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'med_shop_get_cart_count',
                nonce: medShopData.nonce,
            },
            success: function(response) {
                if (response.success) {
                    const count = response.data.count;
                    if (count > 0) {
                        $('.cart-count').text(count).show();
                    } else {
                        $('.cart-count').hide();
                    }
                }
            },
        });
    }

    /**
     * دالة عامة لإضافة المنتج للمفضلة
     */
    window.addToWishlist = function(productId) {
        $.ajax({
            url: medShopData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'med_shop_add_to_wishlist',
                nonce: medShopData.nonce,
                product_id: productId,
            },
            success: function(response) {
                if (response.success) {
                    showNotification('تمت إضافة المنتج للمفضلة');
                }
            },
        });
    };

    /**
     * معالجة البحث
     */
    $('#search-toggle').on('click', function() {
        $('#search-bar').slideToggle();
    });

    /**
     * معالجة الفئات
     */
    $('.category-link').on('click', function(e) {
        e.preventDefault();
        const categorySlug = $(this).data('category');
        window.location.href = '?product_cat=' + categorySlug;
    });

})(jQuery);
