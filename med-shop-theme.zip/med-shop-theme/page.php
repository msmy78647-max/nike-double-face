<?php
/**
 * صفحات عادية
 * 
 * @package Med-Shop
 */

get_header();
?>

<div class="container">
    <div style="margin: 40px 0;">
        <?php
        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <h1 class="entry-title"><?php the_title(); ?></h1>
                    </header>

                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                </article>
                <?php
            }
        }
        ?>
    </div>
</div>

<?php
get_footer();
