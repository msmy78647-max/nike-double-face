<?php
/**
 * تذييل الصفحة
 * 
 * @package Med-Shop
 */
?>

    <!-- الفوتر -->
    <footer class="site-footer">
        <div class="container">
            <div class="footer-content">
                <!-- معلومات المتجر -->
                <div class="footer-section">
                    <h3><?php _e( 'عن المتجر', 'med-shop' ); ?></h3>
                    <p><?php bloginfo( 'description' ); ?></p>
                    <div class="social-links" style="margin-top: 15px;">
                        <a href="https://wa.me/<?php echo esc_attr( med_shop_get_store_info( 'whatsapp_number' ) ); ?>" title="واتساب" target="_blank">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                        <a href="https://instagram.com/<?php echo esc_attr( str_replace( '@', '', med_shop_get_store_info( 'instagram' ) ) ); ?>" title="إنستغرام" target="_blank">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>

                <!-- الروابط السريعة -->
                <div class="footer-section">
                    <h3><?php _e( 'روابط سريعة', 'med-shop' ); ?></h3>
                    <ul>
                        <li><a href="<?php echo esc_url( home_url( '/shop' ) ); ?>"><?php _e( 'المتجر', 'med-shop' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>"><?php _e( 'من نحن', 'med-shop' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>"><?php _e( 'اتصل بنا', 'med-shop' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/reviews' ) ); ?>"><?php _e( 'آراء الزبناء', 'med-shop' ); ?></a></li>
                    </ul>
                </div>

                <!-- الأقسام -->
                <div class="footer-section">
                    <h3><?php _e( 'الأقسام', 'med-shop' ); ?></h3>
                    <ul>
                        <li><a href="<?php echo esc_url( home_url( '/product-category/mens-shoes' ) ); ?>"><?php _e( 'أحذية رجالية', 'med-shop' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/product-category/jackets' ) ); ?>"><?php _e( 'جاكيتات', 'med-shop' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/product-category/ensembles' ) ); ?>"><?php _e( 'أونسومبل', 'med-shop' ); ?></a></li>
                    </ul>
                </div>

                <!-- معلومات التواصل -->
                <div class="footer-section">
                    <h3><?php _e( 'تواصل معنا', 'med-shop' ); ?></h3>
                    <ul>
                        <li>
                            <i class="fas fa-phone"></i>
                            <a href="tel:<?php echo esc_attr( med_shop_get_store_info( 'phone' ) ); ?>">
                                <?php echo esc_html( med_shop_get_store_info( 'phone' ) ); ?>
                            </a>
                        </li>
                        <li>
                            <i class="fas fa-envelope"></i>
                            <a href="mailto:<?php echo esc_attr( med_shop_get_store_info( 'email' ) ); ?>">
                                <?php echo esc_html( med_shop_get_store_info( 'email' ) ); ?>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- الجزء السفلي من الفوتر -->
            <div class="footer-bottom">
                <p>&copy; <?php echo date( 'Y' ); ?> <strong><?php bloginfo( 'name' ); ?></strong>. <?php _e( 'جميع الحقوق محفوظة', 'med-shop' ); ?></p>
                <p><?php _e( 'التوصيل مجاني في جميع مدن المغرب | الدفع عند الاستلام', 'med-shop' ); ?></p>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>
