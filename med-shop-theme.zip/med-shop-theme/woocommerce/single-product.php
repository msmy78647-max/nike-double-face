<?php
/**
 * صفحة المنتج الفردي
 * 
 * @package Med-Shop
 */

get_header();

if ( have_posts() ) {
    while ( have_posts() ) {
        the_post();
        global $product;
        ?>

        <div class="container">
            <div class="single-product">
                <!-- معرض الصور -->
                <div class="product-gallery">
                    <div class="product-main-image">
                        <?php
                        if ( has_post_thumbnail() ) {
                            the_post_thumbnail( 'large', array( 'alt' => get_the_title() ) );
                        } else {
                            echo '<img src="' . esc_url( wc_placeholder_img_src() ) . '" alt="' . get_the_title() . '">';
                        }
                        ?>
                    </div>

                    <!-- الصور المصغرة -->
                    <div class="product-thumbnails">
                        <?php
                        $attachment_ids = $product->get_gallery_image_ids();
                        if ( $attachment_ids ) {
                            foreach ( $attachment_ids as $attachment_id ) {
                                $image_url = wp_get_attachment_image_url( $attachment_id, 'thumbnail' );
                                echo '<div class="product-thumbnail"><img src="' . esc_url( $image_url ) . '" alt="' . get_the_title() . '"></div>';
                            }
                        }
                        ?>
                    </div>
                </div>

                <!-- تفاصيل المنتج -->
                <div class="product-details">
                    <h1><?php the_title(); ?></h1>

                    <!-- التقييم -->
                    <div class="product-rating">
                        <span class="stars">
                            <?php
                            $rating = $product->get_average_rating();
                            for ( $i = 1; $i <= 5; $i++ ) {
                                if ( $i <= $rating ) {
                                    echo '★';
                                } else {
                                    echo '☆';
                                }
                            }
                            ?>
                        </span>
                        <span>(<?php echo esc_html( $product->get_review_count() ); ?> <?php _e( 'تقييم', 'med-shop' ); ?>)</span>
                    </div>

                    <!-- السعر -->
                    <div class="price">
                        <?php echo wc_price( $product->get_price() ); ?>
                    </div>

                    <!-- الوصف القصير -->
                    <p><?php echo wp_kses_post( $product->get_short_description() ); ?></p>

                    <!-- خيارات المنتج -->
                    <div class="product-options">
                        <!-- الحجم -->
                        <?php
                        $sizes = $product->get_attribute( 'pa_size' );
                        if ( $sizes ) {
                            ?>
                            <div class="option-group">
                                <label><?php _e( 'الحجم', 'med-shop' ); ?></label>
                                <div class="size-options">
                                    <?php
                                    $size_options = explode( ',', $sizes );
                                    foreach ( $size_options as $size ) {
                                        echo '<div class="size-option" data-size="' . esc_attr( trim( $size ) ) . '">' . esc_html( trim( $size ) ) . '</div>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>

                        <!-- اللون -->
                        <?php
                        $colors = $product->get_attribute( 'pa_color' );
                        if ( $colors ) {
                            ?>
                            <div class="option-group">
                                <label><?php _e( 'اللون', 'med-shop' ); ?></label>
                                <div class="color-options">
                                    <?php
                                    $color_options = explode( ',', $colors );
                                    $color_map = array(
                                        'أسود' => '#000000',
                                        'أبيض' => '#FFFFFF',
                                        'بني' => '#8B4513',
                                        'رمادي' => '#808080',
                                        'أحمر' => '#FF0000',
                                        'أزرق' => '#0000FF',
                                    );

                                    foreach ( $color_options as $color ) {
                                        $color_name = trim( $color );
                                        $color_hex = $color_map[ $color_name ] ?? '#CCCCCC';
                                        echo '<div class="color-option" data-color="' . esc_attr( $color_name ) . '" style="background-color: ' . esc_attr( $color_hex ) . ';"></div>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>

                    <!-- الكمية والإضافة للسلة -->
                    <div class="product-quantity">
                        <label><?php _e( 'الكمية', 'med-shop' ); ?></label>
                        <div class="quantity-control">
                            <button type="button">−</button>
                            <input type="number" name="quantity" value="1" min="1">
                            <button type="button">+</button>
                        </div>
                    </div>

                    <!-- أزرار الإجراءات -->
                    <div class="product-actions-main">
                        <button class="btn single_add_to_cart_button" data-product_id="<?php echo esc_attr( $product->get_id() ); ?>">
                            <i class="fas fa-shopping-cart"></i> <?php _e( 'أضف للسلة', 'med-shop' ); ?>
                        </button>
                        <button class="btn btn-secondary" onclick="addToWishlist(<?php echo esc_attr( $product->get_id() ); ?>)">
                            <i class="far fa-heart"></i> <?php _e( 'أضف للمفضلة', 'med-shop' ); ?>
                        </button>
                    </div>

                    <!-- معلومات إضافية -->
                    <div style="margin-top: 30px; padding-top: 30px; border-top: 1px solid #e0e0e0;">
                        <p><strong><?php _e( 'التوصيل', 'med-shop' ); ?>:</strong> <?php _e( 'مجاني في جميع مدن المغرب', 'med-shop' ); ?></p>
                        <p><strong><?php _e( 'الدفع', 'med-shop' ); ?>:</strong> <?php _e( 'الدفع عند الاستلام', 'med-shop' ); ?></p>
                        <p><strong><?php _e( 'الاسترجاع', 'med-shop' ); ?>:</strong> <?php _e( '7 أيام ضمان استرجاع', 'med-shop' ); ?></p>
                    </div>
                </div>
            </div>

            <!-- الوصف الكامل -->
            <div class="product-description">
                <h3><?php _e( 'الوصف', 'med-shop' ); ?></h3>
                <?php echo wp_kses_post( $product->get_description() ); ?>
            </div>

            <!-- المنتجات ذات الصلة -->
            <?php
            $related_products = wc_get_related_products( $product->get_id(), 4 );
            if ( $related_products ) {
                ?>
                <section class="products-section" style="margin-top: 60px;">
                    <div class="section-title">
                        <h2><?php _e( 'منتجات ذات صلة', 'med-shop' ); ?></h2>
                    </div>

                    <div class="products-grid">
                        <?php
                        foreach ( $related_products as $related_id ) {
                            $related_product = wc_get_product( $related_id );
                            ?>
                            <div class="product-card">
                                <div class="product-image">
                                    <?php
                                    if ( $related_product->get_image_id() ) {
                                        echo wp_get_attachment_image( $related_product->get_image_id(), 'medium', false, array( 'alt' => $related_product->get_name() ) );
                                    } else {
                                        echo '<img src="' . esc_url( wc_placeholder_img_src() ) . '" alt="' . $related_product->get_name() . '">';
                                    }
                                    ?>
                                </div>

                                <div class="product-info">
                                    <h3 class="product-title"><?php echo esc_html( $related_product->get_name() ); ?></h3>

                                    <div class="product-price">
                                        <span class="price">
                                            <?php echo wc_price( $related_product->get_price() ); ?>
                                        </span>
                                    </div>

                                    <div class="product-actions">
                                        <a href="<?php echo esc_url( $related_product->get_permalink() ); ?>" class="btn">
                                            <?php _e( 'عرض التفاصيل', 'med-shop' ); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </section>
                <?php
            }
            ?>
        </div>

        <?php
    }
}

get_footer();
