<?php
/**
 * صفحات فئات المنتجات
 * 
 * @package Med-Shop
 */

get_header();
?>

<div class="container">
    <!-- رأس الفئة -->
    <div class="category-header">
        <?php
        $term = get_queried_object();
        ?>
        <h1><?php echo esc_html( $term->name ); ?></h1>
        <?php
        if ( $term->description ) {
            echo '<p>' . wp_kses_post( $term->description ) . '</p>';
        }
        ?>
    </div>

    <!-- الفلاتر -->
    <div class="filters-section">
        <h3 class="filters-title"><?php _e( 'تصفية المنتجات', 'med-shop' ); ?></h3>

        <!-- فلتر الحجم -->
        <div class="filter-group">
            <h4><?php _e( 'الحجم', 'med-shop' ); ?></h4>
            <div class="filter-options">
                <div class="filter-option">
                    <input type="checkbox" id="size-m" name="size" value="M">
                    <label for="size-m">M</label>
                </div>
                <div class="filter-option">
                    <input type="checkbox" id="size-l" name="size" value="L">
                    <label for="size-l">L</label>
                </div>
                <div class="filter-option">
                    <input type="checkbox" id="size-xl" name="size" value="XL">
                    <label for="size-xl">XL</label>
                </div>
                <div class="filter-option">
                    <input type="checkbox" id="size-xxl" name="size" value="XXL">
                    <label for="size-xxl">XXL</label>
                </div>
            </div>
        </div>

        <!-- فلتر اللون -->
        <div class="filter-group">
            <h4><?php _e( 'اللون', 'med-shop' ); ?></h4>
            <div class="filter-options">
                <div class="filter-option">
                    <input type="checkbox" id="color-black" name="color" value="أسود">
                    <label for="color-black"><?php _e( 'أسود', 'med-shop' ); ?></label>
                </div>
                <div class="filter-option">
                    <input type="checkbox" id="color-brown" name="color" value="بني">
                    <label for="color-brown"><?php _e( 'بني', 'med-shop' ); ?></label>
                </div>
                <div class="filter-option">
                    <input type="checkbox" id="color-gray" name="color" value="رمادي">
                    <label for="color-gray"><?php _e( 'رمادي', 'med-shop' ); ?></label>
                </div>
                <div class="filter-option">
                    <input type="checkbox" id="color-white" name="color" value="أبيض">
                    <label for="color-white"><?php _e( 'أبيض', 'med-shop' ); ?></label>
                </div>
            </div>
        </div>

        <!-- فلتر السعر -->
        <div class="filter-group">
            <h4><?php _e( 'السعر', 'med-shop' ); ?></h4>
            <div class="price-range">
                <input type="number" name="min_price" placeholder="<?php _e( 'الحد الأدنى', 'med-shop' ); ?>" min="0">
                <span>-</span>
                <input type="number" name="max_price" placeholder="<?php _e( 'الحد الأقصى', 'med-shop' ); ?>" min="0">
            </div>
        </div>

        <!-- زر التطبيق -->
        <button class="btn" onclick="applyAdvancedFilters()" style="width: 100%; margin-top: 20px;">
            <?php _e( 'تطبيق الفلاتر', 'med-shop' ); ?>
        </button>
    </div>

    <!-- المنتجات -->
    <section class="products-section">
        <div class="products-grid">
            <?php
            if ( have_posts() ) {
                while ( have_posts() ) {
                    the_post();
                    global $product;
                    ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php
                            if ( has_post_thumbnail() ) {
                                the_post_thumbnail( 'medium', array( 'alt' => get_the_title() ) );
                            } else {
                                echo '<img src="' . esc_url( wc_placeholder_img_src() ) . '" alt="' . get_the_title() . '">';
                            }
                            ?>
                            <?php
                            if ( $product->is_on_sale() ) {
                                echo '<span class="product-badge">' . __( 'عرض خاص', 'med-shop' ) . '</span>';
                            }
                            ?>
                        </div>

                        <div class="product-info">
                            <div class="product-category">
                                <?php echo esc_html( $term->name ); ?>
                            </div>

                            <h3 class="product-title"><?php the_title(); ?></h3>

                            <div class="product-rating">
                                <?php
                                $rating = $product->get_average_rating();
                                $rating_count = $product->get_review_count();
                                ?>
                                <span class="stars">
                                    <?php
                                    for ( $i = 1; $i <= 5; $i++ ) {
                                        if ( $i <= $rating ) {
                                            echo '★';
                                        } else {
                                            echo '☆';
                                        }
                                    }
                                    ?>
                                </span>
                                <span>(<?php echo esc_html( $rating_count ); ?>)</span>
                            </div>

                            <div class="product-price">
                                <span class="price">
                                    <?php echo wc_price( $product->get_price() ); ?>
                                </span>
                            </div>

                            <div class="product-actions">
                                <a href="<?php the_permalink(); ?>" class="btn">
                                    <?php _e( 'عرض التفاصيل', 'med-shop' ); ?>
                                </a>
                                <button class="btn-wishlist" onclick="addToWishlist(<?php echo esc_attr( $product->get_id() ); ?>)">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<p>' . __( 'لا توجد منتجات في هذا القسم', 'med-shop' ) . '</p>';
            }
            ?>
        </div>
    </section>

    <!-- الترقيم -->
    <?php
    the_posts_pagination( array(
        'mid_size' => 2,
        'prev_text' => __( 'السابق', 'med-shop' ),
        'next_text' => __( 'التالي', 'med-shop' ),
    ) );
    ?>
</div>

<?php
get_footer();
