<?php
/**
 * صفحة البحث
 * 
 * @package Med-Shop
 */

get_header();
?>

<div class="container">
    <div style="margin: 40px 0;">
        <!-- رأس البحث -->
        <div class="category-header">
            <h1><?php printf( __( 'نتائج البحث عن: %s', 'med-shop' ), get_search_query() ); ?></h1>
        </div>

        <!-- نتائج البحث -->
        <div class="search-results">
            <?php
            if ( have_posts() ) {
                while ( have_posts() ) {
                    the_post();
                    ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="margin-bottom: 30px; padding-bottom: 30px; border-bottom: 1px solid #e0e0e0;">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="entry-meta" style="color: #666; margin-bottom: 15px;">
                            <?php
                            if ( get_post_type() === 'product' ) {
                                global $product;
                                echo '<span class="product-category">';
                                $categories = get_the_terms( get_the_ID(), 'product_cat' );
                                if ( $categories ) {
                                    echo esc_html( $categories[0]->name );
                                }
                                echo '</span>';
                            } else {
                                echo '<span>' . get_the_date() . '</span>';
                            }
                            ?>
                        </div>
                        <div class="entry-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="btn" style="margin-top: 15px;">
                            <?php _e( 'اقرأ المزيد', 'med-shop' ); ?>
                        </a>
                    </article>
                    <?php
                }

                // الترقيم
                echo '<div style="margin-top: 40px; text-align: center;">';
                the_posts_pagination( array(
                    'mid_size' => 2,
                    'prev_text' => __( 'السابق', 'med-shop' ),
                    'next_text' => __( 'التالي', 'med-shop' ),
                ) );
                echo '</div>';
            } else {
                ?>
                <div style="text-align: center; padding: 40px 0;">
                    <p><?php _e( 'لم يتم العثور على نتائج تطابق بحثك', 'med-shop' ); ?></p>
                    <p><?php _e( 'يرجى محاولة البحث بكلمات مختلفة', 'med-shop' ); ?></p>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn" style="margin-top: 20px;">
                        <?php _e( 'العودة للرئيسية', 'med-shop' ); ?>
                    </a>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>

<?php
get_footer();
