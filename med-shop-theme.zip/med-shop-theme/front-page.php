<?php
/**
 * الصفحة الرئيسية
 * 
 * @package Med-Shop
 */

get_header();
?>

<!-- السلايدر الرئيسي -->
<div class="hero-slider">
    <div class="hero-slide active">
        <img src="<?php echo esc_url( MED_SHOP_URI . '/assets/images/slider-1.jpg' ); ?>" alt="<?php _e( 'عرض 1', 'med-shop' ); ?>">
        <div class="hero-slide-content">
            <h2><?php _e( 'أحذية رجالية فاخرة', 'med-shop' ); ?></h2>
            <p><?php _e( 'اكتشف مجموعتنا الحصرية من الأحذية الشتوية الراقية', 'med-shop' ); ?></p>
            <a href="<?php echo esc_url( home_url( '/product-category/mens-shoes' ) ); ?>" class="btn">
                <?php _e( 'تسوق الآن', 'med-shop' ); ?>
            </a>
        </div>
    </div>

    <div class="hero-slide">
        <img src="<?php echo esc_url( MED_SHOP_URI . '/assets/images/slider-2.jpg' ); ?>" alt="<?php _e( 'عرض 2', 'med-shop' ); ?>">
        <div class="hero-slide-content">
            <h2><?php _e( 'جاكيتات شتوية عصرية', 'med-shop' ); ?></h2>
            <p><?php _e( 'احصل على أفضل الجاكيتات بأسعار مميزة', 'med-shop' ); ?></p>
            <a href="<?php echo esc_url( home_url( '/product-category/jackets' ) ); ?>" class="btn">
                <?php _e( 'تسوق الآن', 'med-shop' ); ?>
            </a>
        </div>
    </div>

    <div class="hero-slide">
        <img src="<?php echo esc_url( MED_SHOP_URI . '/assets/images/slider-3.jpg' ); ?>" alt="<?php _e( 'عرض 3', 'med-shop' ); ?>">
        <div class="hero-slide-content">
            <h2><?php _e( 'أونسومبل متكاملة', 'med-shop' ); ?></h2>
            <p><?php _e( 'مجموعات ملابس متناسقة وفاخرة', 'med-shop' ); ?></p>
            <a href="<?php echo esc_url( home_url( '/product-category/ensembles' ) ); ?>" class="btn">
                <?php _e( 'تسوق الآن', 'med-shop' ); ?>
            </a>
        </div>
    </div>

    <!-- نقاط التحكم -->
    <div class="slider-controls">
        <span class="slider-dot active" onclick="currentSlide(1)"></span>
        <span class="slider-dot" onclick="currentSlide(2)"></span>
        <span class="slider-dot" onclick="currentSlide(3)"></span>
    </div>
</div>

<div class="container">
    <!-- قسم المنتجات المميزة -->
    <section class="products-section">
        <div class="section-title">
            <h2><?php _e( 'المنتجات المميزة', 'med-shop' ); ?></h2>
        </div>

        <div class="products-grid">
            <?php
            $args = array(
                'post_type'      => 'product',
                'posts_per_page' => 8,
                'meta_key'       => '_featured',
                'meta_value'     => 'yes',
            );

            $loop = new WP_Query( $args );

            if ( $loop->have_posts() ) {
                while ( $loop->have_posts() ) {
                    $loop->the_post();
                    global $product;
                    ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php
                            if ( has_post_thumbnail() ) {
                                the_post_thumbnail( 'medium', array( 'alt' => get_the_title() ) );
                            } else {
                                echo '<img src="' . esc_url( wc_placeholder_img_src() ) . '" alt="' . get_the_title() . '">';
                            }
                            ?>
                            <?php
                            if ( $product->is_on_sale() ) {
                                echo '<span class="product-badge">' . __( 'عرض خاص', 'med-shop' ) . '</span>';
                            }
                            ?>
                        </div>

                        <div class="product-info">
                            <div class="product-category">
                                <?php
                                $categories = get_the_terms( $product->get_id(), 'product_cat' );
                                if ( $categories ) {
                                    echo esc_html( $categories[0]->name );
                                }
                                ?>
                            </div>

                            <h3 class="product-title"><?php the_title(); ?></h3>

                            <div class="product-rating">
                                <?php
                                $rating = $product->get_average_rating();
                                $rating_count = $product->get_review_count();
                                ?>
                                <span class="stars">
                                    <?php
                                    for ( $i = 1; $i <= 5; $i++ ) {
                                        if ( $i <= $rating ) {
                                            echo '★';
                                        } else {
                                            echo '☆';
                                        }
                                    }
                                    ?>
                                </span>
                                <span>(<?php echo esc_html( $rating_count ); ?>)</span>
                            </div>

                            <div class="product-price">
                                <span class="price">
                                    <?php echo wc_price( $product->get_price() ); ?>
                                </span>
                            </div>

                            <div class="product-actions">
                                <a href="<?php the_permalink(); ?>" class="btn">
                                    <?php _e( 'عرض التفاصيل', 'med-shop' ); ?>
                                </a>
                                <button class="btn-wishlist" onclick="addToWishlist(<?php echo esc_attr( $product->get_id() ); ?>)">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<p>' . __( 'لا توجد منتجات مميزة حالياً', 'med-shop' ) . '</p>';
            }

            wp_reset_postdata();
            ?>
        </div>
    </section>

    <!-- قسم الأقسام الرئيسية -->
    <section class="products-section" style="margin-top: 80px;">
        <div class="section-title">
            <h2><?php _e( 'تسوق حسب القسم', 'med-shop' ); ?></h2>
        </div>

        <div class="products-grid">
            <?php
            $categories = get_terms( array(
                'taxonomy'   => 'product_cat',
                'hide_empty' => true,
                'number'     => 3,
            ) );

            foreach ( $categories as $category ) {
                $thumbnail_id = get_term_meta( $category->term_id, 'thumbnail_id', true );
                $image_url = wp_get_attachment_url( $thumbnail_id );
                ?>
                <div class="product-card" style="cursor: pointer; text-align: center; padding: 30px;">
                    <?php
                    if ( $image_url ) {
                        echo '<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $category->name ) . '" style="width: 100%; height: 250px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;">';
                    }
                    ?>
                    <h3 style="margin-bottom: 15px;"><?php echo esc_html( $category->name ); ?></h3>
                    <p style="color: #666; margin-bottom: 20px;"><?php echo esc_html( $category->description ); ?></p>
                    <a href="<?php echo esc_url( get_term_link( $category ) ); ?>" class="btn">
                        <?php _e( 'تصفح القسم', 'med-shop' ); ?>
                    </a>
                </div>
                <?php
            }
            ?>
        </div>
    </section>

    <!-- قسم المميزات -->
    <section class="products-section" style="margin-top: 80px; margin-bottom: 80px;">
        <div class="section-title">
            <h2><?php _e( 'لماذا تختار Med-Shop؟', 'med-shop' ); ?></h2>
        </div>

        <div class="products-grid">
            <div class="product-card" style="text-align: center; padding: 30px;">
                <div style="font-size: 3rem; color: #FC6E20; margin-bottom: 20px;">
                    <i class="fas fa-shipping-fast"></i>
                </div>
                <h3><?php _e( 'توصيل مجاني', 'med-shop' ); ?></h3>
                <p><?php _e( 'توصيل مجاني في جميع مدن المغرب', 'med-shop' ); ?></p>
            </div>

            <div class="product-card" style="text-align: center; padding: 30px;">
                <div style="font-size: 3rem; color: #FC6E20; margin-bottom: 20px;">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <h3><?php _e( 'الدفع عند الاستلام', 'med-shop' ); ?></h3>
                <p><?php _e( 'ادفع عند استلام طلبك بكل أمان وسهولة', 'med-shop' ); ?></p>
            </div>

            <div class="product-card" style="text-align: center; padding: 30px;">
                <div style="font-size: 3rem; color: #FC6E20; margin-bottom: 20px;">
                    <i class="fas fa-undo"></i>
                </div>
                <h3><?php _e( 'سياسة الاسترجاع', 'med-shop' ); ?></h3>
                <p><?php _e( 'استرجع منتجك في خلال 7 أيام بدون مشاكل', 'med-shop' ); ?></p>
            </div>

            <div class="product-card" style="text-align: center; padding: 30px;">
                <div style="font-size: 3rem; color: #FC6E20; margin-bottom: 20px;">
                    <i class="fas fa-headset"></i>
                </div>
                <h3><?php _e( 'دعم العملاء', 'med-shop' ); ?></h3>
                <p><?php _e( 'فريق دعم متاح لمساعدتك 24/7', 'med-shop' ); ?></p>
            </div>
        </div>
    </section>
</div>

<script>
    // سكريبت السلايدر
    let slideIndex = 1;

    function showSlide(n) {
        let slides = document.querySelectorAll('.hero-slide');
        let dots = document.querySelectorAll('.slider-dot');

        if (n > slides.length) {
            slideIndex = 1;
        }
        if (n < 1) {
            slideIndex = slides.length;
        }

        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));

        slides[slideIndex - 1].classList.add('active');
        dots[slideIndex - 1].classList.add('active');
    }

    function currentSlide(n) {
        slideIndex = n;
        showSlide(slideIndex);
    }

    // تغيير السلايد تلقائياً كل 5 ثواني
    setInterval(function() {
        slideIndex++;
        showSlide(slideIndex);
    }, 5000);

    // دالة إضافة المنتج للمفضلة
    function addToWishlist(productId) {
        alert('تمت إضافة المنتج للمفضلة');
    }
</script>

<?php
get_footer();
